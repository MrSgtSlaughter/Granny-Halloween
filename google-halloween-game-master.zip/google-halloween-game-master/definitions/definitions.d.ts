/**
 * 通用无依赖声明
 */

//坐标点兼容Utils.Point
interface Coordinate {
  x: number;
  y: number;
}