{
"frames": {
	"p3_1.png": {
		"frame": {"x":83, "y":152, "w":82, "h":75},
		"spriteSourceSize": {"x":3,"y":2,"w":92,"h":79},
		"sourceSize": {"w":92,"h":79}
	},
	"p3_2.png": {
		"frame": {"x":87, "y":0, "w":81, "h":73},
		"spriteSourceSize": {"x":1,"y":4,"w":91,"h":79},
		"sourceSize": {"w":91,"h":79}
	},
	"p3_3.png": {
		"frame": {"x":87, "y":74, "w":79, "h":73},
		"spriteSourceSize": {"x":2,"y":4,"w":88,"h":79},
		"sourceSize": {"w":88,"h":79}
	},
	"p3_4.png": {
		"frame": {"x":167, "y":74, "w":78, "h":72},
		"spriteSourceSize": {"x":5,"y":5,"w":88,"h":79},
		"sourceSize": {"w":88,"h":79}
	},
	"p3_5.png": {
		"frame": {"x":0, "y":76, "w":86, "h":75},
		"spriteSourceSize": {"x":2,"y":2,"w":90,"h":79},
		"sourceSize": {"w":90,"h":79}
	},
	"p3_6.png": {
		"frame": {"x":0, "y":152, "w":82, "h":75},
		"spriteSourceSize": {"x":4,"y":2,"w":88,"h":79},
		"sourceSize": {"w":88,"h":79}
	},
	"p3_7.png": {
		"frame": {"x":166, "y":148, "w":78, "h":72},
		"spriteSourceSize": {"x":6,"y":4,"w":89,"h":79},
		"sourceSize": {"w":89,"h":79}
	},
	"p3_8.png": {
		"frame": {"x":0, "y":0, "w":86, "h":75},
		"spriteSourceSize": {"x":2,"y":1,"w":89,"h":79},
		"sourceSize": {"w":89,"h":79}
	}

},
"meta": {
	"image": "sprites.png",
	"size": {"w": 246, "h": 228},
	"scale": "1"
}
}