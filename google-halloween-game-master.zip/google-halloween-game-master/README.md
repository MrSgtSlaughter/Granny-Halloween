# google-halloween-game
The clone of google's halloween game, just for fun. UNDER DEVELOPMENT!  
DEMO: https://wilsoncook.github.io/google-halloween-game/dist/index.html  
original edition(full game): https://www.google.com/logos/2016/halloween16/halloween16.html?hl=en
